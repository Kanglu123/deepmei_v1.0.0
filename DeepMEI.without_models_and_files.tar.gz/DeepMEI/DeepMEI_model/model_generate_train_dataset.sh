#input_gt=input_gt.txt
#cp $input_gt input_gt.txt
conda activate tf-gpu
python model_generate_train_dataset.py
