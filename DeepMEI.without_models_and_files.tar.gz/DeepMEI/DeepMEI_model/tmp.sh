echo $PWD
