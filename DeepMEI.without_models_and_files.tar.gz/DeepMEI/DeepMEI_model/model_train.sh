input_gt=/data2/output/DeepMEI/train_dataset/train_all_gt.txt
#cp $input_gt input_gt.txt
#conda activate tf_gpu_c
python model_train.py
