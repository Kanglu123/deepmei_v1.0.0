def test_x(i):
	print(str(i))
