samtools view ${2} ${1} -O SAM -o regions/${3}_${1}.bam 2>/dev/null
