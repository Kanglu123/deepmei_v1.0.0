#conda activate RepeatMasker
RepeatMasker  -species human $1 $2 -pa 1 2>/dev/null
